# Fileora extracted PNG assets

All images are PNG. Backgrounds have been made transparent where possible.

## Logos
- `logos/full_lockups/`: six cropped logo concept cards, including symbol, Fileora wordmark, and tagline.
- `logos/symbols_only/`: six standalone logo symbols.

## Interface icons
- `interface_icons/`: 40 individually cropped icons from the Fileora Interface Icon Library.

Note: These are raster extractions from the supplied presentation images, not original vector artwork. Small edge artifacts or slight softness may remain because the source images are raster mockups.

## Official assets (added)
- `official/01-Official-Fileora-Logo.png`: the supplied official full logo artwork.
- `official/02-Android-Launcher-Icon.png`: the supplied Android launcher icon artwork.

The two official files are preserved as uploaded. The logo exploration concepts remain separate under `logos/`.
